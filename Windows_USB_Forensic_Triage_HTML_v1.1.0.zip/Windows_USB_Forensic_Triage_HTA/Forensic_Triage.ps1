﻿[CmdletBinding()]
param(
    [ValidateRange(1,3650)][int]$LookbackDays = 30,
    [ValidateRange(100,50000)][int]$MaxEvents = 5000,
    [ValidateRange(100,50000)][int]$MaxBrowserRows = 5000,
    [ValidateRange(100,50000)][int]$MaxFileRows = 5000,
    [switch]$NoBrowserHistory,
    [switch]$NoElevationNotice,
    [switch]$Authorized,
    [string]$StatusFile = ''
)

Set-StrictMode -Off
$ErrorActionPreference = 'Continue'
$ToolVersion = '1.1.0'
$CollectionStart = Get-Date
$StartTime = $CollectionStart.AddDays(-1 * $LookbackDays)
$script:DataSets = @()
$script:Notices = @()
$script:LogPath = $null
$script:CsvRoot = $null
$script:TempRoot = $null
$script:OutputRoot = $null

function Write-UIStatus {
    param(
        [string]$State = 'Running',
        [string]$Phase = '',
        [int]$Progress = -1,
        [string]$Message = '',
        [string]$ReportPath = '',
        [string]$OutputPath = ''
    )
    if ([string]::IsNullOrWhiteSpace($StatusFile)) { return }
    try {
        $statusDir = Split-Path -Parent $StatusFile
        if (-not [string]::IsNullOrWhiteSpace($statusDir)) {
            New-Item -ItemType Directory -Path $statusDir -Force -ErrorAction SilentlyContinue | Out-Null
        }
        $values = [ordered]@{
            State      = $State
            Phase      = $Phase
            Progress   = $Progress
            Message    = $Message
            ReportPath = $ReportPath
            OutputPath = $OutputPath
            Updated    = (Get-Date).ToString('o')
        }
        $lines = foreach ($k in $values.Keys) {
            $v = [string]$values[$k]
            if ($null -eq $v) { $v = '' }
            '{0}={1}' -f $k, [Uri]::EscapeDataString($v)
        }
        $tmp = $StatusFile + '.tmp'
        [IO.File]::WriteAllLines($tmp, [string[]]$lines, (New-Object Text.UTF8Encoding($false)))
        Move-Item -LiteralPath $tmp -Destination $StatusFile -Force -ErrorAction SilentlyContinue
    } catch { }
}

function Test-IsAdministrator {
    try {
        $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object Security.Principal.WindowsPrincipal -ArgumentList $identity
        return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $line = ('{0} [{1}] {2}' -f (Get-Date).ToString('o'), $Level.ToUpperInvariant(), $Message)
    if ($script:LogPath) {
        try { Add-Content -LiteralPath $script:LogPath -Value $line -Encoding UTF8 -ErrorAction SilentlyContinue } catch { }
    }
    if ($Level -eq 'ERROR') { Write-Host $Message -ForegroundColor Red }
    elseif ($Level -eq 'WARN') { Write-Host $Message -ForegroundColor Yellow }
    else { Write-Host $Message }
}

function Add-Notice {
    param([string]$Component, [string]$Status, [string]$Message)
    $script:Notices += [pscustomobject]@{
        Time = (Get-Date).ToString('o')
        Component = $Component
        Status = $Status
        Message = $Message
    }
    $logLevel = 'INFO'
    if ($Status -match 'Error|Unavailable|Skipped|Partial') { $logLevel = 'WARN' }
    Write-Log ("{0}: {1}" -f $Component, $Message) $logLevel
}

function Convert-ToFlatString {
    param($Value)
    if ($null -eq $Value) { return '' }
    if ($Value -is [System.Array]) { return (($Value | ForEach-Object { [string]$_ }) -join '; ') }
    return ([string]$Value -replace "`r|`n", ' ')
}

function Save-DataSet {
    param(
        [Parameter(Mandatory=$true)][string]$Name,
        [Parameter(Mandatory=$true)][string]$Description,
        [object[]]$Data
    )
    $safe = ($Name -replace '[^A-Za-z0-9_.-]', '_')
    $fileName = $safe + '.csv'
    $path = Join-Path $script:CsvRoot $fileName
    $rows = @($Data).Count
    try {
        if ($rows -gt 0) {
            $Data | Export-Csv -LiteralPath $path -NoTypeInformation -Encoding UTF8 -Force
        } else {
            [pscustomobject]@{ Status='No rows'; Message='No records were returned for this artifact during this collection.' } |
                Export-Csv -LiteralPath $path -NoTypeInformation -Encoding UTF8 -Force
        }
        $preview = @($Data | Select-Object -First 200)
        $script:DataSets += [pscustomobject]@{
            Name = $Name
            Description = $Description
            Rows = $rows
            FileName = $fileName
            Preview = $preview
        }
        Write-Log ("Saved {0} ({1} rows)." -f $Name, $rows)
    } catch {
        Add-Notice $Name 'Error' ("Could not write dataset: {0}" -f $_.Exception.Message)
    }
}

function Get-EventDataMap {
    param($EventRecord)
    $map = @{}
    try {
        [xml]$xml = $EventRecord.ToXml()
        foreach ($node in @($xml.Event.EventData.Data)) {
            $name = [string]$node.Name
            if (-not [string]::IsNullOrWhiteSpace($name)) { $map[$name] = [string]$node.'#text' }
        }
    } catch { }
    return $map
}

function Get-MapValue {
    param([hashtable]$Map, [string]$Key)
    if ($Map -and $Map.ContainsKey($Key)) { return [string]$Map[$Key] }
    return ''
}

function Get-LogonTypeName {
    param([string]$Type)
    switch ($Type) {
        '2'  { 'Interactive' }
        '3'  { 'Network' }
        '4'  { 'Batch' }
        '5'  { 'Service' }
        '7'  { 'Unlock' }
        '8'  { 'NetworkCleartext' }
        '9'  { 'NewCredentials' }
        '10' { 'RemoteInteractive/RDP' }
        '11' { 'CachedInteractive' }
        default { 'Other/Unknown' }
    }
}

function Initialize-WinSqlite {
    if ('WinSqliteBridge' -as [type]) { return $true }
    $code = @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

public static class WinSqliteBridge
{
    private const int SQLITE_ROW = 100;
    private const int SQLITE_DONE = 101;

    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_open16([MarshalAs(UnmanagedType.LPWStr)] string filename, out IntPtr db);

    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_close(IntPtr db);

    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_prepare_v2(IntPtr db, byte[] sql, int nByte, out IntPtr stmt, IntPtr tail);

    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_step(IntPtr stmt);

    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_finalize(IntPtr stmt);

    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_column_count(IntPtr stmt);

    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern IntPtr sqlite3_column_name(IntPtr stmt, int index);

    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern IntPtr sqlite3_column_text(IntPtr stmt, int index);

    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern IntPtr sqlite3_errmsg(IntPtr db);

    private static string PtrToUtf8(IntPtr ptr)
    {
        if (ptr == IntPtr.Zero) return "";
        int len = 0;
        while (Marshal.ReadByte(ptr, len) != 0) len++;
        byte[] bytes = new byte[len];
        Marshal.Copy(ptr, bytes, 0, len);
        return Encoding.UTF8.GetString(bytes);
    }

    public static string[][] Query(string dbPath, string sql, int maxRows)
    {
        IntPtr db = IntPtr.Zero;
        IntPtr stmt = IntPtr.Zero;
        var output = new List<string[]>();
        int rc = sqlite3_open16(dbPath, out db);
        if (rc != 0) throw new Exception("sqlite open failed: " + PtrToUtf8(sqlite3_errmsg(db)));
        try
        {
            byte[] query = Encoding.UTF8.GetBytes(sql + "\0");
            rc = sqlite3_prepare_v2(db, query, query.Length - 1, out stmt, IntPtr.Zero);
            if (rc != 0) throw new Exception("sqlite prepare failed: " + PtrToUtf8(sqlite3_errmsg(db)));
            int cols = sqlite3_column_count(stmt);
            string[] headers = new string[cols];
            for (int i = 0; i < cols; i++) headers[i] = PtrToUtf8(sqlite3_column_name(stmt, i));
            output.Add(headers);

            int rows = 0;
            while (rows < maxRows)
            {
                rc = sqlite3_step(stmt);
                if (rc == SQLITE_DONE) break;
                if (rc != SQLITE_ROW) throw new Exception("sqlite step failed: " + PtrToUtf8(sqlite3_errmsg(db)));
                string[] values = new string[cols];
                for (int i = 0; i < cols; i++) values[i] = PtrToUtf8(sqlite3_column_text(stmt, i));
                output.Add(values);
                rows++;
            }
            return output.ToArray();
        }
        finally
        {
            if (stmt != IntPtr.Zero) sqlite3_finalize(stmt);
            if (db != IntPtr.Zero) sqlite3_close(db);
        }
    }
}
'@
    try {
        Add-Type -TypeDefinition $code -Language CSharp -ErrorAction Stop
        return $true
    } catch {
        Add-Notice 'Browser history parser' 'Unavailable' ("Could not initialize Windows SQLite bridge: {0}" -f $_.Exception.Message)
        return $false
    }
}

function Invoke-WinSqliteQuery {
    param([string]$DatabasePath, [string]$Sql, [int]$MaxRows)
    $raw = [WinSqliteBridge]::Query($DatabasePath, $Sql, $MaxRows)
    if ($null -eq $raw -or $raw.Length -lt 1) { return @() }
    $headers = $raw[0]
    $items = New-Object System.Collections.Generic.List[object]
    for ($r = 1; $r -lt $raw.Length; $r++) {
        $ordered = [ordered]@{}
        for ($c = 0; $c -lt $headers.Length; $c++) {
            $ordered[[string]$headers[$c]] = [string]$raw[$r][$c]
        }
        $items.Add([pscustomobject]$ordered)
    }
    return $items.ToArray()
}

function Copy-SqliteForRead {
    param([string]$SourcePath)
    $dir = Join-Path $script:TempRoot ([guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $dir -Force | Out-Null
    $dest = Join-Path $dir ([IO.Path]::GetFileName($SourcePath))
    Copy-Item -LiteralPath $SourcePath -Destination $dest -Force -ErrorAction Stop
    foreach ($suffix in @('-wal','-shm','-journal')) {
        $sidecar = $SourcePath + $suffix
        if (Test-Path -LiteralPath $sidecar) {
            try { Copy-Item -LiteralPath $sidecar -Destination ($dest + $suffix) -Force -ErrorAction Stop } catch { }
        }
    }
    return $dest
}

function Get-RegistryValues {
    param([string]$Path, [string]$Scope, [string]$Category)
    $results = @()
    try {
        if (Test-Path -LiteralPath $Path) {
            $key = Get-Item -LiteralPath $Path -ErrorAction Stop
            foreach ($name in @($key.GetValueNames())) {
                $results += [pscustomobject]@{
                    Scope = $Scope
                    Category = $Category
                    RegistryPath = $Path
                    Name = $name
                    Value = Convert-ToFlatString ($key.GetValue($name))
                }
            }
        }
    } catch { }
    return $results
}

function Convert-BytesToReadable {
    param($Value)
    if ($Value -is [byte[]]) {
        try {
            $u = [Text.Encoding]::Unicode.GetString($Value).Trim([char]0)
            if ($u -match '[A-Za-z0-9\\]') { return $u }
        } catch { }
        return (($Value | ForEach-Object { $_.ToString('X2') }) -join '')
    }
    return Convert-ToFlatString $Value
}

# ---------------- Authorization and output setup ----------------
Clear-Host
Write-Host 'Windows USB Forensic Triage' -ForegroundColor Cyan
Write-Host ("Version {0}" -f $ToolVersion)
Write-Host ''
Write-Host 'AUTHORIZED USE ONLY. This performs live-response forensic triage and writes results to the folder containing this tool.' -ForegroundColor Yellow
Write-Host 'It does not upload evidence, install persistence, decrypt credentials, or bypass Windows access controls.'
Write-Host ''
Write-UIStatus 'Running' 'Authorization' 2 'Collector launched. Verifying authorization and output location.'
if (-not $Authorized) {
    $consent = Read-Host 'Type YES to confirm you are authorized to examine this computer'
    if ($consent -cne 'YES') {
        Write-UIStatus 'Cancelled' 'Authorization' 0 'Authorization not confirmed. No collection was started.'
        Write-Host 'Authorization not confirmed. No collection was started.' -ForegroundColor Yellow
        exit 1
    }
}

$IsAdmin = Test-IsAdministrator
if (-not $IsAdmin -and -not $NoElevationNotice) {
    Write-Host 'NOTICE: This session is not elevated. Security-log and system-level evidence may be incomplete.' -ForegroundColor Yellow
}

$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$hostSafe = $(if ([string]::IsNullOrWhiteSpace($env:COMPUTERNAME)) { 'UNKNOWN_HOST' } else { $env:COMPUTERNAME -replace '[^A-Za-z0-9_.-]','_' })
$script:OutputRoot = Join-Path $PSScriptRoot ('TRIAGE_OUTPUT\' + $hostSafe + '_' + $stamp)
$script:CsvRoot = Join-Path $script:OutputRoot 'CSVs'
$script:TempRoot = Join-Path $script:OutputRoot '_TEMP_WORK'
try {
    New-Item -ItemType Directory -Path $script:CsvRoot -Force | Out-Null
    New-Item -ItemType Directory -Path $script:TempRoot -Force | Out-Null
} catch {
    Write-UIStatus 'Error' 'Output setup' 0 ("Cannot create output folder on the tool drive: {0}" -f $_.Exception.Message)
    Write-Host ("Cannot create output folder on the tool drive: {0}" -f $_.Exception.Message) -ForegroundColor Red
    exit 2
}
$script:LogPath = Join-Path $script:OutputRoot 'Collection_Log.txt'
Write-Log ("Collection started. Tool version {0}. Lookback {1} days. Admin={2}" -f $ToolVersion, $LookbackDays, $IsAdmin)
Write-UIStatus 'Running' 'System and account triage' 8 'Collecting host, operating-system, user, profile, and account information.' '' $script:OutputRoot

try {
    $qualifier = Split-Path -Qualifier $PSScriptRoot
    if ($qualifier) {
        $drive = New-Object System.IO.DriveInfo -ArgumentList $qualifier
        Write-Log ("Tool drive: {0} type={1} format={2}" -f $drive.Name, $drive.DriveType, $drive.DriveFormat)
        if ($drive.DriveType -ne [IO.DriveType]::Removable) { Add-Notice 'Tool drive' 'Informational' ("Tool is running from drive type {0}, not a Windows Removable drive. Collection will continue." -f $drive.DriveType) }
    }
} catch { }

# ---------------- System and account data ----------------
Write-Host ''
Write-Host '[1/9] System and account triage...' -ForegroundColor Cyan
try {
    $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
    $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop
    $bios = Get-CimInstance Win32_BIOS -ErrorAction SilentlyContinue
    $cpu = Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1
    $tz = try { (Get-TimeZone).Id } catch { [TimeZoneInfo]::Local.Id }
    $toolHash = try { (Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash } catch { '' }
    $systemInfo = [pscustomobject]@{
        ComputerName = $env:COMPUTERNAME
        DomainOrWorkgroup = $cs.Domain
        PartOfDomain = $cs.PartOfDomain
        Manufacturer = $cs.Manufacturer
        Model = $cs.Model
        TotalPhysicalMemoryBytes = $cs.TotalPhysicalMemory
        OperatingSystem = $os.Caption
        OSVersion = $os.Version
        BuildNumber = $os.BuildNumber
        OSArchitecture = $os.OSArchitecture
        InstallDate = Convert-ToFlatString $os.InstallDate
        LastBootUpTime = Convert-ToFlatString $os.LastBootUpTime
        TimeZone = $tz
        BIOSSerialNumber = $(if ($bios) { $bios.SerialNumber } else { '' })
        Processor = $(if ($cpu) { $cpu.Name } else { '' })
        CurrentIdentity = [Security.Principal.WindowsIdentity]::GetCurrent().Name
        ElevatedAdministrator = $IsAdmin
        PowerShellVersion = $PSVersionTable.PSVersion.ToString()
        CollectionStartedLocal = $CollectionStart.ToString('o')
        CollectionStartedUTC = $CollectionStart.ToUniversalTime().ToString('o')
        LookbackDays = $LookbackDays
        ToolVersion = $ToolVersion
        ToolSHA256 = $toolHash
        ToolPath = $PSCommandPath
    }
    Save-DataSet 'System_Information' 'Host, operating-system, hardware, time-zone, current identity, and collection metadata.' @($systemInfo)
} catch { Add-Notice 'System information' 'Error' $_.Exception.Message }

try {
    $netAdapters = @(Get-CimInstance Win32_NetworkAdapterConfiguration -Filter 'IPEnabled=True' -ErrorAction Stop | ForEach-Object {
        [pscustomobject]@{
            Description = $_.Description
            MACAddress = $_.MACAddress
            IPAddress = Convert-ToFlatString $_.IPAddress
            IPSubnet = Convert-ToFlatString $_.IPSubnet
            DefaultGateway = Convert-ToFlatString $_.DefaultIPGateway
            DNSServers = Convert-ToFlatString $_.DNSServerSearchOrder
            DHCPEnabled = $_.DHCPEnabled
            DHCPServer = $_.DHCPServer
        }
    })
    Save-DataSet 'Network_Adapters' 'IP-enabled network interfaces and addressing observed during collection.' $netAdapters
} catch { Add-Notice 'Network adapters' 'Error' $_.Exception.Message }

$profiles = @()
try {
    $profiles = @(Get-CimInstance Win32_UserProfile -ErrorAction Stop | Where-Object { $_.LocalPath -and -not $_.Special } | ForEach-Object {
        [pscustomobject]@{
            SID = $_.SID
            LocalPath = $_.LocalPath
            Loaded = $_.Loaded
            Status = $_.Status
            LastUseTime = Convert-ToFlatString $_.LastUseTime
        }
    })
    Save-DataSet 'User_Profiles' 'Accessible Windows user profiles, SIDs, loaded state, and profile last-use metadata.' $profiles
} catch { Add-Notice 'User profiles' 'Error' $_.Exception.Message }

try {
    $localUsers = @()
    if (Get-Command Get-LocalUser -ErrorAction SilentlyContinue) {
        $localUsers = @(Get-LocalUser -ErrorAction Stop | ForEach-Object {
            [pscustomobject]@{
                Name = $_.Name
                SID = Convert-ToFlatString $_.SID
                Enabled = $_.Enabled
                Description = $_.Description
                LastLogon = Convert-ToFlatString $_.LastLogon
                PasswordLastSet = Convert-ToFlatString $_.PasswordLastSet
                PasswordExpires = Convert-ToFlatString $_.PasswordExpires
                UserMayChangePassword = $_.UserMayChangePassword
                PasswordRequired = $_.PasswordRequired
            }
        })
    } else {
        $localUsers = @(Get-CimInstance Win32_UserAccount -Filter 'LocalAccount=True' -ErrorAction Stop | ForEach-Object {
            [pscustomobject]@{
                Name = $_.Name; SID = $_.SID; Enabled = -not $_.Disabled; Description = $_.Description
                LastLogon = ''; PasswordLastSet=''; PasswordExpires=$_.PasswordExpires; UserMayChangePassword=''; PasswordRequired=$_.PasswordRequired
            }
        })
    }
    Save-DataSet 'Local_Users' 'Local account inventory. LastLogon is included when the LocalAccounts module exposes it.' $localUsers
} catch { Add-Notice 'Local users' 'Error' $_.Exception.Message }

try {
    $admins = @()
    if (Get-Command Get-LocalGroupMember -ErrorAction SilentlyContinue) {
        $admins = @(Get-LocalGroupMember -Group 'Administrators' -ErrorAction Stop | ForEach-Object {
            [pscustomobject]@{ Name=$_.Name; ObjectClass=$_.ObjectClass; PrincipalSource=Convert-ToFlatString $_.PrincipalSource; SID=Convert-ToFlatString $_.SID }
        })
    } else {
        $group = [ADSI]("WinNT://{0}/Administrators,group" -f $env:COMPUTERNAME)
        foreach ($m in @($group.psbase.Invoke('Members'))) {
            $t = $m.GetType()
            $name = $t.InvokeMember('Name',[Reflection.BindingFlags]::GetProperty,$null,$m,$null)
            $class = $t.InvokeMember('Class',[Reflection.BindingFlags]::GetProperty,$null,$m,$null)
            $admins += [pscustomobject]@{ Name=$name; ObjectClass=$class; PrincipalSource='ADSI'; SID='' }
        }
    }
    Save-DataSet 'Local_Administrators' 'Membership of the local Administrators group.' $admins
} catch { Add-Notice 'Local Administrators' 'Partial' $_.Exception.Message }

Write-UIStatus 'Running' 'Login and execution history' 22 'Reading Windows event logs for logons, failures, and process creation where auditing is available.' '' $script:OutputRoot

# ---------------- Event-log login and process history ----------------
Write-Host '[2/9] Security-event triage...' -ForegroundColor Cyan
try {
    $loginEvents = @(Get-WinEvent -FilterHashtable @{LogName='Security'; Id=@(4624,4625); StartTime=$StartTime} -MaxEvents $MaxEvents -ErrorAction Stop | ForEach-Object {
        $m = Get-EventDataMap $_
        $lt = Get-MapValue $m 'LogonType'
        [pscustomobject]@{
            TimeCreated = $_.TimeCreated.ToString('o')
            EventID = $_.Id
            Result = $(if ($_.Id -eq 4624) { 'Successful logon' } else { 'Failed logon' })
            TargetUser = Get-MapValue $m 'TargetUserName'
            TargetDomain = Get-MapValue $m 'TargetDomainName'
            TargetUserSID = Get-MapValue $m 'TargetUserSid'
            LogonType = $lt
            LogonTypeName = Get-LogonTypeName $lt
            WorkstationName = Get-MapValue $m 'WorkstationName'
            SourceIPAddress = Get-MapValue $m 'IpAddress'
            SourcePort = Get-MapValue $m 'IpPort'
            AuthenticationPackage = Get-MapValue $m 'AuthenticationPackageName'
            ProcessName = Get-MapValue $m 'ProcessName'
            FailureReason = Get-MapValue $m 'FailureReason'
            Status = Get-MapValue $m 'Status'
            SubStatus = Get-MapValue $m 'SubStatus'
        }
    })
    Save-DataSet 'Login_History' 'Windows Security events 4624 and 4625 within the lookback window. Availability depends on audit policy, log retention, and permissions.' $loginEvents
} catch { Add-Notice 'Login history' 'Unavailable' ("Security logons could not be read: {0}" -f $_.Exception.Message); Save-DataSet 'Login_History' 'Windows Security events 4624 and 4625. Collection was unavailable; see Collection_Notices.' @() }

try {
    $procEvents = @(Get-WinEvent -FilterHashtable @{LogName='Security'; Id=4688; StartTime=$StartTime} -MaxEvents $MaxEvents -ErrorAction Stop | ForEach-Object {
        $m = Get-EventDataMap $_
        [pscustomobject]@{
            TimeCreated = $_.TimeCreated.ToString('o')
            User = ((Get-MapValue $m 'SubjectDomainName') + '\' + (Get-MapValue $m 'SubjectUserName')).Trim('\')
            NewProcessName = Get-MapValue $m 'NewProcessName'
            NewProcessID = Get-MapValue $m 'NewProcessId'
            ParentProcessName = Get-MapValue $m 'ParentProcessName'
            CommandLine = Get-MapValue $m 'CommandLine'
            TokenElevationType = Get-MapValue $m 'TokenElevationType'
        }
    })
    Save-DataSet 'Process_Creation_History' 'Security event 4688 process creation. Command lines appear only when the applicable audit policy is enabled.' $procEvents
} catch { Add-Notice 'Process creation history' 'Unavailable' $_.Exception.Message; Save-DataSet 'Process_Creation_History' 'Security event 4688 process creation. Collection was unavailable; see Collection_Notices.' @() }

try {
    $auditText = & auditpol.exe /get /category:* 2>&1
    $auditRows = @($auditText | ForEach-Object { [pscustomobject]@{ Line = [string]$_ } })
    Save-DataSet 'Audit_Policy' 'Current Windows advanced audit-policy output, useful for interpreting absent Security events.' $auditRows
} catch { Add-Notice 'Audit policy' 'Unavailable' $_.Exception.Message }

Write-UIStatus 'Running' 'USB device history' 34 'Collecting USBSTOR, USB, mounted-device, and current PnP evidence.' '' $script:OutputRoot

# ---------------- USB history ----------------
Write-Host '[3/9] USB and mounted-device history...' -ForegroundColor Cyan
try {
    $usbHistory = @()
    foreach ($root in @('Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Enum\USBSTOR','Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Enum\USB')) {
        if (-not (Test-Path -LiteralPath $root)) { continue }
        foreach ($deviceClass in @(Get-ChildItem -LiteralPath $root -ErrorAction SilentlyContinue)) {
            foreach ($instance in @(Get-ChildItem -LiteralPath $deviceClass.PSPath -ErrorAction SilentlyContinue)) {
                try {
                    $p = Get-ItemProperty -LiteralPath $instance.PSPath -ErrorAction Stop
                    $usbHistory += [pscustomobject]@{
                        Source = $(if ($root -like '*USBSTOR') { 'USBSTOR' } else { 'USB' })
                        DeviceClass = $deviceClass.PSChildName
                        InstanceID = $instance.PSChildName
                        FriendlyName = Convert-ToFlatString $p.FriendlyName
                        DeviceDescription = Convert-ToFlatString $p.DeviceDesc
                        Manufacturer = Convert-ToFlatString $p.Mfg
                        Service = Convert-ToFlatString $p.Service
                        Class = Convert-ToFlatString $p.Class
                        ClassGUID = Convert-ToFlatString $p.ClassGUID
                        ContainerID = Convert-ToFlatString $p.ContainerID
                        HardwareID = Convert-ToFlatString $p.HardwareID
                        CompatibleIDs = Convert-ToFlatString $p.CompatibleIDs
                        RegistryPath = $instance.Name
                    }
                } catch { }
            }
        }
    }
    Save-DataSet 'USB_Device_History' 'Historical USB and USB mass-storage enumeration records from HKLM SYSTEM Enum USB/USBSTOR.' $usbHistory
} catch { Add-Notice 'USB history' 'Error' $_.Exception.Message }

try {
    $mounted = @()
    $key = Get-Item -LiteralPath 'Registry::HKEY_LOCAL_MACHINE\SYSTEM\MountedDevices' -ErrorAction Stop
    foreach ($name in @($key.GetValueNames())) {
        $mounted += [pscustomobject]@{ ValueName=$name; Mapping=Convert-BytesToReadable ($key.GetValue($name)) }
    }
    Save-DataSet 'Mounted_Devices' 'MountedDevices registry mappings, including drive-letter and volume associations where readable.' $mounted
} catch { Add-Notice 'Mounted devices' 'Unavailable' $_.Exception.Message }

try {
    if (Get-Command Get-PnpDevice -ErrorAction SilentlyContinue) {
        $presentUsb = @(Get-PnpDevice -PresentOnly -ErrorAction Stop | Where-Object { $_.InstanceId -like 'USB*' -or $_.InstanceId -like 'USBSTOR*' } | ForEach-Object {
            [pscustomobject]@{ Class=$_.Class; FriendlyName=$_.FriendlyName; InstanceId=$_.InstanceId; Status=$_.Status; Problem=$_.Problem }
        })
        Save-DataSet 'USB_Currently_Present' 'USB-related Plug and Play devices present at collection time.' $presentUsb
    }
} catch { Add-Notice 'Present USB devices' 'Partial' $_.Exception.Message }

Write-UIStatus 'Running' 'Web and download history' 46 'Examining accessible browser history and download databases.' '' $script:OutputRoot

# ---------------- Browser history ----------------
Write-Host '[4/9] Browser history and download artifacts...' -ForegroundColor Cyan
$browserHistory = @()
$browserDownloads = @()
if ($NoBrowserHistory) {
    Add-Notice 'Browser history' 'Skipped' 'Browser collection disabled by -NoBrowserHistory.'
} else {
    $sqliteReady = Initialize-WinSqlite
    if ($sqliteReady) {
        $browserSpecs = @(
            [pscustomobject]@{ Name='Google Chrome'; Type='Chromium'; Relative='AppData\Local\Google\Chrome\User Data\*\History' },
            [pscustomobject]@{ Name='Microsoft Edge'; Type='Chromium'; Relative='AppData\Local\Microsoft\Edge\User Data\*\History' },
            [pscustomobject]@{ Name='Brave'; Type='Chromium'; Relative='AppData\Local\BraveSoftware\Brave-Browser\User Data\*\History' },
            [pscustomobject]@{ Name='Opera'; Type='Chromium'; Relative='AppData\Roaming\Opera Software\Opera Stable\History' },
            [pscustomobject]@{ Name='Opera GX'; Type='Chromium'; Relative='AppData\Roaming\Opera Software\Opera GX Stable\History' },
            [pscustomobject]@{ Name='Firefox'; Type='Firefox'; Relative='AppData\Roaming\Mozilla\Firefox\Profiles\*\places.sqlite' }
        )
        foreach ($profile in $profiles) {
            $userLabel = Split-Path -Leaf $profile.LocalPath
            foreach ($spec in $browserSpecs) {
                $pattern = Join-Path $profile.LocalPath $spec.Relative
                $dbFiles = @(Get-ChildItem -Path $pattern -File -ErrorAction SilentlyContinue)
                foreach ($db in $dbFiles) {
                    $browserProfile = Split-Path -Leaf (Split-Path -Parent $db.FullName)
                    try {
                        $copy = Copy-SqliteForRead $db.FullName
                        if ($spec.Type -eq 'Chromium') {
                            $sql = "SELECT datetime((v.visit_time/1000000)-11644473600,'unixepoch') AS VisitUTC, u.url AS URL, ifnull(u.title,'') AS Title, CAST(u.visit_count AS TEXT) AS VisitCount, CAST(u.typed_count AS TEXT) AS TypedCount, CAST(v.transition AS TEXT) AS Transition FROM visits v JOIN urls u ON v.url=u.id ORDER BY v.visit_time DESC LIMIT $MaxBrowserRows;"
                            $rows = @(Invoke-WinSqliteQuery $copy $sql $MaxBrowserRows)
                            foreach ($r in $rows) {
                                $browserHistory += [pscustomobject]@{ User=$userLabel; Browser=$spec.Name; BrowserProfile=$browserProfile; VisitUTC=$r.VisitUTC; URL=$r.URL; Title=$r.Title; VisitCount=$r.VisitCount; TypedCount=$r.TypedCount; VisitTypeOrTransition=$r.Transition; SourceDatabase=$db.FullName }
                            }
                            $downloadSql = "SELECT datetime((d.start_time/1000000)-11644473600,'unixepoch') AS StartUTC, ifnull(d.target_path,'') AS TargetPath, ifnull(d.current_path,'') AS CurrentPath, ifnull(duc.url,'') AS URL, CAST(d.received_bytes AS TEXT) AS ReceivedBytes, CAST(d.total_bytes AS TEXT) AS TotalBytes, CAST(d.state AS TEXT) AS State, CAST(d.danger_type AS TEXT) AS DangerType FROM downloads d LEFT JOIN downloads_url_chains duc ON d.id=duc.id AND duc.chain_index=0 ORDER BY d.start_time DESC LIMIT $MaxBrowserRows;"
                            try {
                                $dRows = @(Invoke-WinSqliteQuery $copy $downloadSql $MaxBrowserRows)
                                foreach ($r in $dRows) {
                                    $browserDownloads += [pscustomobject]@{ User=$userLabel; Browser=$spec.Name; BrowserProfile=$browserProfile; StartUTC=$r.StartUTC; URL=$r.URL; TargetPath=$r.TargetPath; CurrentPath=$r.CurrentPath; ReceivedBytes=$r.ReceivedBytes; TotalBytes=$r.TotalBytes; State=$r.State; DangerType=$r.DangerType; SourceDatabase=$db.FullName }
                                }
                            } catch { Add-Notice ("$($spec.Name) downloads") 'Partial' ("Could not query {0}: {1}" -f $db.FullName, $_.Exception.Message) }
                        } else {
                            $sql = "SELECT datetime(h.visit_date/1000000,'unixepoch') AS VisitUTC, p.url AS URL, ifnull(p.title,'') AS Title, CAST(p.visit_count AS TEXT) AS VisitCount, CAST(h.visit_type AS TEXT) AS VisitType FROM moz_historyvisits h JOIN moz_places p ON h.place_id=p.id ORDER BY h.visit_date DESC LIMIT $MaxBrowserRows;"
                            $rows = @(Invoke-WinSqliteQuery $copy $sql $MaxBrowserRows)
                            foreach ($r in $rows) {
                                $browserHistory += [pscustomobject]@{ User=$userLabel; Browser=$spec.Name; BrowserProfile=$browserProfile; VisitUTC=$r.VisitUTC; URL=$r.URL; Title=$r.Title; VisitCount=$r.VisitCount; TypedCount=''; VisitTypeOrTransition=$r.VisitType; SourceDatabase=$db.FullName }
                            }
                        }
                    } catch {
                        Add-Notice ("$($spec.Name) history") 'Partial' ("Could not read {0}: {1}" -f $db.FullName, $_.Exception.Message)
                    }
                }
            }
        }
    }
}
Save-DataSet 'Browser_History' 'Chrome, Edge, Brave, Opera/Opera GX, and Firefox history from accessible profile SQLite databases. Times are normalized to UTC by the SQL query.' $browserHistory
Save-DataSet 'Browser_Download_History' 'Chromium-family download records from accessible History databases.' $browserDownloads

Write-UIStatus 'Running' 'Applications and volatile state' 58 'Collecting installed applications, Prefetch, processes, services, and live network state.' '' $script:OutputRoot

# ---------------- Application and live-response data ----------------
Write-Host '[5/9] Application and volatile-state triage...' -ForegroundColor Cyan
try {
    $apps = @()
    $appPaths = @(
        [pscustomobject]@{Path='Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'; Scope='Machine 64-bit'},
        [pscustomobject]@{Path='Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'; Scope='Machine 32-bit'}
    )
    foreach ($ap in $appPaths) {
        foreach ($a in @(Get-ItemProperty -Path $ap.Path -ErrorAction SilentlyContinue)) {
            if ($a.DisplayName) {
                $apps += [pscustomobject]@{ Scope=$ap.Scope; DisplayName=$a.DisplayName; DisplayVersion=$a.DisplayVersion; Publisher=$a.Publisher; InstallDate=$a.InstallDate; InstallLocation=$a.InstallLocation; UninstallString=$a.UninstallString }
            }
        }
    }
    foreach ($sidKey in @(Get-ChildItem -LiteralPath 'Registry::HKEY_USERS' -ErrorAction SilentlyContinue | Where-Object { $_.PSChildName -match '^S-1-5-21-' -and $_.PSChildName -notmatch '_Classes$' })) {
        $p = 'Registry::HKEY_USERS\' + $sidKey.PSChildName + '\Software\Microsoft\Windows\CurrentVersion\Uninstall\*'
        foreach ($a in @(Get-ItemProperty -Path $p -ErrorAction SilentlyContinue)) {
            if ($a.DisplayName) { $apps += [pscustomobject]@{ Scope=('User ' + $sidKey.PSChildName); DisplayName=$a.DisplayName; DisplayVersion=$a.DisplayVersion; Publisher=$a.Publisher; InstallDate=$a.InstallDate; InstallLocation=$a.InstallLocation; UninstallString=$a.UninstallString } }
        }
    }
    $apps = @($apps | Sort-Object DisplayName,DisplayVersion,Scope -Unique)
    Save-DataSet 'Installed_Applications' 'Installed-software registry inventory from machine and currently loaded user hives.' $apps
} catch { Add-Notice 'Installed applications' 'Error' $_.Exception.Message }

try {
    $prefetchPath = Join-Path $env:WINDIR 'Prefetch'
    $prefetch = @()
    if (Test-Path -LiteralPath $prefetchPath) {
        $prefetch = @(Get-ChildItem -LiteralPath $prefetchPath -Filter '*.pf' -File -ErrorAction Stop | Sort-Object LastWriteTime -Descending | Select-Object -First $MaxFileRows | ForEach-Object {
            [pscustomobject]@{ FileName=$_.Name; LastWriteTime=$_.LastWriteTime.ToString('o'); CreationTime=$_.CreationTime.ToString('o'); SizeBytes=$_.Length; FullPath=$_.FullName }
        })
    }
    Save-DataSet 'Prefetch_Inventory' 'Windows Prefetch file inventory and file-system timestamps. This is not a full .pf execution-time/run-count parser.' $prefetch
} catch { Add-Notice 'Prefetch' 'Unavailable' $_.Exception.Message }

try {
    $bamRows = @()
    foreach ($bamRoot in @('Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\bam\State\UserSettings','Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\dam\State\UserSettings')) {
        if (-not (Test-Path -LiteralPath $bamRoot)) { continue }
        foreach ($sidKey in @(Get-ChildItem -LiteralPath $bamRoot -ErrorAction SilentlyContinue)) {
            try {
                $rk = Get-Item -LiteralPath $sidKey.PSPath -ErrorAction Stop
                foreach ($valueName in @($rk.GetValueNames())) {
                    $raw = $rk.GetValue($valueName)
                    $lastExec = ''
                    if ($raw -is [byte[]] -and $raw.Length -ge 8) {
                        try {
                            $ft = [BitConverter]::ToInt64($raw,0)
                            if ($ft -gt 0) { $lastExec = [DateTime]::FromFileTimeUtc($ft).ToString('o') }
                        } catch { }
                    }
                    $bamRows += [pscustomobject]@{ Source=(Split-Path -Leaf (Split-Path -Parent (Split-Path -Parent $bamRoot))); UserSID=$sidKey.PSChildName; Executable=$valueName; LastExecutionUTC=$lastExec; RegistryPath=$sidKey.Name }
                }
            } catch { }
        }
    }
    Save-DataSet 'BAM_DAM_Application_History' 'Best-effort Background/Desktop Activity Moderator execution history. LastExecutionUTC is decoded from the leading FILETIME when present; availability and retention vary by Windows version.' $bamRows
} catch { Add-Notice 'BAM/DAM application history' 'Partial' $_.Exception.Message }

try {
    $running = @(Get-CimInstance Win32_Process -ErrorAction Stop | ForEach-Object {
        [pscustomobject]@{ Name=$_.Name; ProcessID=$_.ProcessId; ParentProcessID=$_.ParentProcessId; CreationDate=Convert-ToFlatString $_.CreationDate; ExecutablePath=$_.ExecutablePath; CommandLine=$_.CommandLine }
    })
    Save-DataSet 'Running_Processes' 'Process snapshot at collection time, including executable path and command line where permitted.' $running
} catch { Add-Notice 'Running processes' 'Error' $_.Exception.Message }

try {
    $services = @(Get-CimInstance Win32_Service -ErrorAction Stop | ForEach-Object {
        [pscustomobject]@{ Name=$_.Name; DisplayName=$_.DisplayName; State=$_.State; StartMode=$_.StartMode; StartName=$_.StartName; ProcessId=$_.ProcessId; PathName=$_.PathName }
    })
    Save-DataSet 'Services' 'Windows service inventory including start mode, service account, PID, and image path.' $services
} catch { Add-Notice 'Services' 'Error' $_.Exception.Message }

try {
    if (Get-Command Get-NetTCPConnection -ErrorAction SilentlyContinue) {
        $tcp = @(Get-NetTCPConnection -ErrorAction Stop | ForEach-Object {
            [pscustomobject]@{ State=$_.State; LocalAddress=$_.LocalAddress; LocalPort=$_.LocalPort; RemoteAddress=$_.RemoteAddress; RemotePort=$_.RemotePort; OwningProcess=$_.OwningProcess; CreationTime=Convert-ToFlatString $_.CreationTime }
        })
        Save-DataSet 'Active_TCP_Connections' 'TCP endpoint snapshot at collection time.' $tcp
    }
} catch { Add-Notice 'TCP connections' 'Unavailable' $_.Exception.Message }

try {
    if (Get-Command Get-DnsClientCache -ErrorAction SilentlyContinue) {
        $dns = @(Get-DnsClientCache -ErrorAction Stop | ForEach-Object {
            [pscustomobject]@{ Entry=$_.Entry; Name=$_.Name; Data=$_.Data; Type=$_.Type; Status=$_.Status; Section=$_.Section; TimeToLive=$_.TimeToLive }
        })
        Save-DataSet 'DNS_Cache' 'Windows DNS resolver cache at collection time.' $dns
    }
} catch { Add-Notice 'DNS cache' 'Unavailable' $_.Exception.Message }

try {
    if (Get-Command Get-NetNeighbor -ErrorAction SilentlyContinue) {
        $neighbors = @(Get-NetNeighbor -ErrorAction Stop | ForEach-Object {
            [pscustomobject]@{ InterfaceAlias=$_.InterfaceAlias; IPAddress=$_.IPAddress; LinkLayerAddress=$_.LinkLayerAddress; State=$_.State; AddressFamily=$_.AddressFamily }
        })
        Save-DataSet 'Network_Neighbors' 'Current IPv4/IPv6 neighbor cache (ARP/NDP-related state).' $neighbors
    }
} catch { Add-Notice 'Network neighbors' 'Unavailable' $_.Exception.Message }

Write-UIStatus 'Running' 'File and recent activity' 69 'Collecting Recent Items, Downloads metadata, Recycle Bin information, and related file activity.' '' $script:OutputRoot

# ---------------- File and recent-activity artifacts ----------------
Write-Host '[6/9] Recent file activity...' -ForegroundColor Cyan
try {
    $recent = @()
    $shell = New-Object -ComObject WScript.Shell
    foreach ($profile in $profiles) {
        $userLabel = Split-Path -Leaf $profile.LocalPath
        $recentDir = Join-Path $profile.LocalPath 'AppData\Roaming\Microsoft\Windows\Recent'
        if (-not (Test-Path -LiteralPath $recentDir)) { continue }
        foreach ($lnk in @(Get-ChildItem -LiteralPath $recentDir -Filter '*.lnk' -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First $MaxFileRows)) {
            try {
                $sc = $shell.CreateShortcut($lnk.FullName)
                $recent += [pscustomobject]@{ User=$userLabel; ShortcutName=$lnk.Name; ShortcutLastWriteTime=$lnk.LastWriteTime.ToString('o'); TargetPath=$sc.TargetPath; Arguments=$sc.Arguments; WorkingDirectory=$sc.WorkingDirectory; ShortcutPath=$lnk.FullName }
            } catch { }
        }
    }
    if ($shell) { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($shell) }
    Save-DataSet 'Recent_File_Shortcuts' 'Per-profile Recent-folder .lnk inventory with shortcut targets where WScript.Shell can resolve them.' $recent
} catch { Add-Notice 'Recent file shortcuts' 'Partial' $_.Exception.Message }

try {
    $downloads = @()
    foreach ($profile in $profiles) {
        $userLabel = Split-Path -Leaf $profile.LocalPath
        $dir = Join-Path $profile.LocalPath 'Downloads'
        if (-not (Test-Path -LiteralPath $dir)) { continue }
        foreach ($f in @(Get-ChildItem -LiteralPath $dir -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First $MaxFileRows)) {
            $downloads += [pscustomobject]@{ User=$userLabel; FileName=$f.Name; FullPath=$f.FullName; SizeBytes=$f.Length; CreationTime=$f.CreationTime.ToString('o'); LastWriteTime=$f.LastWriteTime.ToString('o'); LastAccessTime=$f.LastAccessTime.ToString('o'); Extension=$f.Extension }
        }
    }
    Save-DataSet 'Downloads_Folder_History' 'Top-level file metadata from accessible user Downloads folders. No file contents are copied.' $downloads
} catch { Add-Notice 'Downloads folders' 'Partial' $_.Exception.Message }

try {
    $recycleRows = @()
    $recycleRoot = Join-Path $env:SystemDrive '$Recycle.Bin'
    if (Test-Path -LiteralPath $recycleRoot) {
        foreach ($iFile in @(Get-ChildItem -LiteralPath $recycleRoot -Filter '$I*' -File -Recurse -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First $MaxFileRows)) {
            $origPath = ''
            $origSize = ''
            $deletedUtc = ''
            $formatVersion = ''
            try {
                $b = [IO.File]::ReadAllBytes($iFile.FullName)
                if ($b.Length -ge 24) {
                    $formatVersion = [BitConverter]::ToInt64($b,0)
                    $origSize = [BitConverter]::ToInt64($b,8)
                    $ft = [BitConverter]::ToInt64($b,16)
                    if ($ft -gt 0) { $deletedUtc = [DateTime]::FromFileTimeUtc($ft).ToString('o') }
                    if ($b.Length -gt 28 -and $formatVersion -ge 2) {
                        $chars = [BitConverter]::ToInt32($b,24)
                        $maxBytes = $b.Length - 28
                        $wantBytes = [Math]::Min([Math]::Max(0,$chars * 2),$maxBytes)
                        if ($wantBytes -gt 0) { $origPath = [Text.Encoding]::Unicode.GetString($b,28,$wantBytes).Trim([char]0) }
                    } elseif ($b.Length -gt 24) {
                        $origPath = [Text.Encoding]::Unicode.GetString($b,24,$b.Length-24).Trim([char]0)
                    }
                }
            } catch { }
            $recycleRows += [pscustomobject]@{ UserSID=$iFile.Directory.Name; MetadataFile=$iFile.FullName; FormatVersion=$formatVersion; OriginalPath=$origPath; OriginalSizeBytes=$origSize; DeletedUTC=$deletedUtc; MetadataLastWriteTime=$iFile.LastWriteTime.ToString('o') }
        }
    }
    Save-DataSet 'Recycle_Bin_History' 'Best-effort parse of Windows $I Recycle Bin metadata, including original path, original size, and deletion FILETIME when the format can be decoded.' $recycleRows
} catch { Add-Notice 'Recycle Bin history' 'Partial' $_.Exception.Message }

try {
    $artifactPaths = @(
        (Join-Path $env:WINDIR 'AppCompat\Programs\Amcache.hve'),
        (Join-Path $env:WINDIR 'System32\sru\SRUDB.dat'),
        (Join-Path $env:WINDIR 'System32\winevt\Logs\Security.evtx'),
        (Join-Path $env:WINDIR 'System32\winevt\Logs\System.evtx'),
        (Join-Path $env:WINDIR 'System32\winevt\Logs\Application.evtx'),
        (Join-Path $env:WINDIR 'System32\config\SYSTEM'),
        (Join-Path $env:WINDIR 'System32\config\SOFTWARE'),
        (Join-Path $env:WINDIR 'System32\config\SAM'),
        (Join-Path $env:WINDIR 'System32\config\SECURITY')
    )
    $inventory = @()
    foreach ($p in $artifactPaths) {
        if (Test-Path -LiteralPath $p) {
            try { $f = Get-Item -LiteralPath $p -ErrorAction Stop; $inventory += [pscustomobject]@{ Path=$p; Exists=$true; SizeBytes=$f.Length; CreationTime=$f.CreationTime.ToString('o'); LastWriteTime=$f.LastWriteTime.ToString('o'); LastAccessTime=$f.LastAccessTime.ToString('o') } } catch { $inventory += [pscustomobject]@{Path=$p;Exists=$true;SizeBytes='';CreationTime='';LastWriteTime='';LastAccessTime='Access denied'} }
        } else { $inventory += [pscustomobject]@{Path=$p;Exists=$false;SizeBytes='';CreationTime='';LastWriteTime='';LastAccessTime=''} }
    }
    Save-DataSet 'Key_Forensic_Artifact_Inventory' 'Presence and file metadata for several high-value Windows forensic artifacts. Files are not copied by this triage collector.' $inventory
} catch { Add-Notice 'Artifact inventory' 'Partial' $_.Exception.Message }

Write-UIStatus 'Running' 'Persistence and remote use' 79 'Collecting startup persistence, scheduled tasks, and remote-desktop history.' '' $script:OutputRoot

# ---------------- Persistence and remote-use history ----------------
Write-Host '[7/9] Persistence, scheduled tasks, and RDP history...' -ForegroundColor Cyan
try {
    $persistence = @()
    foreach ($k in @(
        [pscustomobject]@{Path='Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Run';Scope='Machine';Category='Run'},
        [pscustomobject]@{Path='Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce';Scope='Machine';Category='RunOnce'},
        [pscustomobject]@{Path='Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run';Scope='Machine 32-bit';Category='Run'}
    )) { $persistence += @(Get-RegistryValues $k.Path $k.Scope $k.Category) }
    foreach ($sidKey in @(Get-ChildItem -LiteralPath 'Registry::HKEY_USERS' -ErrorAction SilentlyContinue | Where-Object { $_.PSChildName -match '^S-1-5-21-' -and $_.PSChildName -notmatch '_Classes$' })) {
        $sid = $sidKey.PSChildName
        foreach ($suffix in @('Software\Microsoft\Windows\CurrentVersion\Run','Software\Microsoft\Windows\CurrentVersion\RunOnce')) {
            $p = 'Registry::HKEY_USERS\' + $sid + '\' + $suffix
            $persistence += @(Get-RegistryValues $p ('User ' + $sid) (Split-Path -Leaf $suffix))
        }
    }
    $startupFiles = @()
    foreach ($profile in $profiles) {
        $userLabel = Split-Path -Leaf $profile.LocalPath
        $dir = Join-Path $profile.LocalPath 'AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup'
        if (Test-Path -LiteralPath $dir) {
            foreach ($f in @(Get-ChildItem -LiteralPath $dir -File -ErrorAction SilentlyContinue)) { $startupFiles += [pscustomobject]@{Scope=('User ' + $userLabel);Name=$f.Name;FullPath=$f.FullName;LastWriteTime=$f.LastWriteTime.ToString('o');SizeBytes=$f.Length} }
        }
    }
    $commonStartup = Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\StartUp'
    if (Test-Path -LiteralPath $commonStartup) {
        foreach ($f in @(Get-ChildItem -LiteralPath $commonStartup -File -ErrorAction SilentlyContinue)) { $startupFiles += [pscustomobject]@{Scope='All Users';Name=$f.Name;FullPath=$f.FullName;LastWriteTime=$f.LastWriteTime.ToString('o');SizeBytes=$f.Length} }
    }
    Save-DataSet 'Registry_Run_Persistence' 'Run/RunOnce persistence from machine and currently loaded user registry hives.' $persistence
    Save-DataSet 'Startup_Folder_Persistence' 'Files present in per-user and common Startup folders.' $startupFiles
} catch { Add-Notice 'Persistence' 'Partial' $_.Exception.Message }

try {
    if (Get-Command Get-ScheduledTask -ErrorAction SilentlyContinue) {
        $tasks = @(Get-ScheduledTask -ErrorAction Stop | ForEach-Object {
            $task = $_
            foreach ($action in @($task.Actions)) {
                [pscustomobject]@{ TaskPath=$task.TaskPath; TaskName=$task.TaskName; State=$task.State; Author=$task.Author; Description=$task.Description; UserId=$task.Principal.UserId; RunLevel=$task.Principal.RunLevel; Execute=$action.Execute; Arguments=$action.Arguments; WorkingDirectory=$action.WorkingDirectory }
            }
        })
        Save-DataSet 'Scheduled_Tasks' 'Scheduled-task inventory with principals and executable actions.' $tasks
    }
} catch { Add-Notice 'Scheduled tasks' 'Unavailable' $_.Exception.Message }

try {
    $rdp = @()
    foreach ($sidKey in @(Get-ChildItem -LiteralPath 'Registry::HKEY_USERS' -ErrorAction SilentlyContinue | Where-Object { $_.PSChildName -match '^S-1-5-21-' -and $_.PSChildName -notmatch '_Classes$' })) {
        $sid = $sidKey.PSChildName
        $defaultPath = 'Registry::HKEY_USERS\' + $sid + '\Software\Microsoft\Terminal Server Client\Default'
        $rdp += @(Get-RegistryValues $defaultPath ('User ' + $sid) 'RDP MRU')
        $serversPath = 'Registry::HKEY_USERS\' + $sid + '\Software\Microsoft\Terminal Server Client\Servers'
        if (Test-Path -LiteralPath $serversPath) {
            foreach ($server in @(Get-ChildItem -LiteralPath $serversPath -ErrorAction SilentlyContinue)) {
                $u = ''
                try { $u = (Get-ItemProperty -LiteralPath $server.PSPath -ErrorAction SilentlyContinue).UsernameHint } catch { }
                $rdp += [pscustomobject]@{ Scope=('User ' + $sid); Category='RDP Server'; RegistryPath=$server.Name; Name=$server.PSChildName; Value=Convert-ToFlatString $u }
            }
        }
    }
    Save-DataSet 'RDP_Client_History' 'Remote Desktop client MRU/server history from currently loaded user hives.' $rdp
} catch { Add-Notice 'RDP history' 'Partial' $_.Exception.Message }

Write-UIStatus 'Running' 'Security context and event summaries' 87 'Collecting Defender findings, event summaries, audit context, and forensic artifact inventory.' '' $script:OutputRoot

# ---------------- Defender and event summaries ----------------
Write-Host '[8/9] Security-product and operating-event triage...' -ForegroundColor Cyan
try {
    if (Get-Command Get-MpThreatDetection -ErrorAction SilentlyContinue) {
        $detections = @(Get-MpThreatDetection -ErrorAction Stop | ForEach-Object {
            [pscustomobject]@{ ThreatID=$_.ThreatID; ThreatStatusID=$_.ThreatStatusID; InitialDetectionTime=Convert-ToFlatString $_.InitialDetectionTime; LastThreatStatusChangeTime=Convert-ToFlatString $_.LastThreatStatusChangeTime; ActionSuccess=$_.ActionSuccess; CurrentThreatExecutionStatusID=$_.CurrentThreatExecutionStatusID; ProcessName=$_.ProcessName; Resources=Convert-ToFlatString $_.Resources }
        })
        Save-DataSet 'Defender_Detections' 'Microsoft Defender threat-detection history when Defender cmdlets and data are available.' $detections
    }
} catch { Add-Notice 'Defender detections' 'Unavailable' $_.Exception.Message }

try {
    $eventSummary = @()
    foreach ($logName in @('System','Application')) {
        try {
            $eventSummary += @(Get-WinEvent -FilterHashtable @{LogName=$logName; Level=@(1,2,3); StartTime=$StartTime} -MaxEvents ([Math]::Max(100,[int]($MaxEvents/2))) -ErrorAction Stop | ForEach-Object {
                $msg = ''
                try { $msg = ([string]$_.Message -replace "`r|`n", ' ') } catch { }
                if ($msg.Length -gt 1200) { $msg = $msg.Substring(0,1200) + '...' }
                [pscustomobject]@{ LogName=$logName; TimeCreated=$_.TimeCreated.ToString('o'); EventID=$_.Id; Level=$_.LevelDisplayName; Provider=$_.ProviderName; Message=$msg }
            })
        } catch { Add-Notice ("$logName event log") 'Partial' $_.Exception.Message }
    }
    Save-DataSet 'System_Application_Warnings_Errors' 'Recent Critical, Error, and Warning records from the System and Application logs.' $eventSummary
} catch { Add-Notice 'System/Application event summary' 'Partial' $_.Exception.Message }

Write-UIStatus 'Running' 'Building reports' 93 'Writing CSV evidence tables and constructing the consolidated HTML report.' '' $script:OutputRoot

# ---------------- Final notices, report, and hashes ----------------
Write-Host '[9/9] Building reports and integrity files...' -ForegroundColor Cyan
Save-DataSet 'Collection_Notices' 'Collection coverage, limitations, inaccessible artifacts, and parser notices. Review this table before interpreting missing evidence.' $script:Notices

$summaryPath = Join-Path $script:OutputRoot 'Triage_Summary.csv'
$summary = @($script:DataSets | ForEach-Object {
    [pscustomobject]@{ Category=$_.Name; Rows=$_.Rows; CsvFile=('CSVs\' + $_.FileName); Description=$_.Description }
})
$summary | Export-Csv -LiteralPath $summaryPath -NoTypeInformation -Encoding UTF8 -Force

# Create a single normalized CSV containing every field from every category.
# This complements the per-category CSVs without forcing unlike schemas into one wide table.
$allFindingsPath = Join-Path $script:OutputRoot 'Triage_All_Findings.csv'
try {
    $utf8Bom = New-Object Text.UTF8Encoding -ArgumentList $true
    $allWriter = New-Object IO.StreamWriter -ArgumentList $allFindingsPath, $false, $utf8Bom
    try {
        $allWriter.WriteLine('Category,RecordNumber,Field,Value')
        foreach ($ds in $script:DataSets) {
            $csvPath = Join-Path $script:CsvRoot $ds.FileName
            if (-not (Test-Path -LiteralPath $csvPath)) { continue }
            $recordNumber = 0
            foreach ($row in @(Import-Csv -LiteralPath $csvPath -ErrorAction SilentlyContinue)) {
                $recordNumber++
                foreach ($prop in @($row.PSObject.Properties)) {
                    $vals = @([string]$ds.Name, [string]$recordNumber, [string]$prop.Name, [string]$prop.Value)
                    $escaped = @($vals | ForEach-Object { '"' + (($_ -replace '"','""') -replace "`r|`n", ' ') + '"' })
                    $allWriter.WriteLine(($escaped -join ','))
                }
            }
        }
    } finally { $allWriter.Dispose() }
} catch { Add-Notice 'Consolidated CSV' 'Partial' ("Could not create Triage_All_Findings.csv: {0}" -f $_.Exception.Message) }

$reportPath = Join-Path $script:OutputRoot 'Triage_Report.html'
$totalRows = ($script:DataSets | Measure-Object -Property Rows -Sum).Sum
if ($null -eq $totalRows) { $totalRows = 0 }
$collectionEnd = Get-Date

$css = @'
:root{--bg:#f4f7fb;--panel:#ffffff;--ink:#172033;--muted:#5e6a7d;--line:#dce3ee;--accent:#1769aa;--accent2:#0e4f85;--soft:#eaf3fb;--warn:#8a5a00;--bad:#9b1c1c;--ok:#1f6b44}
*{box-sizing:border-box} body{margin:0;background:var(--bg);color:var(--ink);font-family:Segoe UI,Arial,sans-serif;line-height:1.45}.wrap{max-width:1500px;margin:0 auto;padding:28px}.hero{background:linear-gradient(135deg,#fff,#eef6fd);border:1px solid var(--line);border-radius:16px;padding:26px 30px;box-shadow:0 8px 24px rgba(23,32,51,.06)}h1{margin:0 0 6px;font-size:30px}h2{font-size:21px;margin:0}.subtitle{color:var(--muted)}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px;margin:18px 0}.card{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:14px 16px}.card b{display:block;font-size:22px;color:var(--accent2)}.nav{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:14px 18px;margin:18px 0}.nav a{display:inline-block;margin:4px 12px 4px 0;color:var(--accent);text-decoration:none}.section{background:var(--panel);border:1px solid var(--line);border-radius:14px;margin:16px 0;padding:20px;overflow:auto}.desc{color:var(--muted);margin:8px 0 12px}.download{display:inline-block;padding:7px 10px;border-radius:8px;background:var(--soft);color:var(--accent2);text-decoration:none;font-weight:600;margin-bottom:12px}table{border-collapse:collapse;width:100%;font-size:12.5px}th,td{border:1px solid var(--line);padding:7px 8px;text-align:left;vertical-align:top;word-break:break-word}th{background:#eef3f8;position:sticky;top:0}tr:nth-child(even) td{background:#fbfcfe}.note{border-left:4px solid #d28b00;background:#fff8e8;padding:10px 12px;border-radius:6px;margin:14px 0}.footer{color:var(--muted);font-size:12px;padding:18px 2px 40px}@media print{body{background:#fff}.wrap{max-width:none;padding:0}.section,.hero,.nav,.card{box-shadow:none;break-inside:avoid}.nav{display:none}th{position:static}}
'@

$sb = New-Object Text.StringBuilder
[void]$sb.AppendLine('<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">')
[void]$sb.AppendLine('<title>Windows Forensic Triage Report</title><style>' + $css + '</style></head><body><div class="wrap">')
[void]$sb.AppendLine('<div class="hero"><h1>Windows Forensic Triage Report</h1><div class="subtitle">Local-only live-response report generated by Windows USB Forensic Triage ' + $ToolVersion + '</div>')
[void]$sb.AppendLine('<div class="cards">')
[void]$sb.AppendLine('<div class="card"><span>Computer</span><b>' + [Net.WebUtility]::HtmlEncode($env:COMPUTERNAME) + '</b></div>')
[void]$sb.AppendLine('<div class="card"><span>Collection started</span><b style="font-size:15px">' + $CollectionStart.ToString('yyyy-MM-dd HH:mm:ss zzz') + '</b></div>')
[void]$sb.AppendLine('<div class="card"><span>Categories</span><b>' + $script:DataSets.Count + '</b></div>')
[void]$sb.AppendLine('<div class="card"><span>Total table rows</span><b>' + $totalRows + '</b></div>')
[void]$sb.AppendLine('<div class="card"><span>Elevated</span><b>' + $IsAdmin + '</b></div>')
[void]$sb.AppendLine('</div><div class="note"><b>Interpretation note:</b> Missing records are not automatically negative evidence. Review <a href="#Collection_Notices">Collection Notices</a> for permissions, audit-policy, browser-locking, and artifact-availability limitations.</div></div>')

[void]$sb.AppendLine('<div class="nav"><b>Report sections:</b><br>')
foreach ($ds in $script:DataSets) {
    $anchor = ($ds.Name -replace '[^A-Za-z0-9_-]','_')
    [void]$sb.AppendLine('<a href="#' + $anchor + '">' + [Net.WebUtility]::HtmlEncode($ds.Name -replace '_',' ') + '</a>')
}
[void]$sb.AppendLine('</div>')

foreach ($ds in $script:DataSets) {
    $anchor = ($ds.Name -replace '[^A-Za-z0-9_-]','_')
    [void]$sb.AppendLine('<section class="section" id="' + $anchor + '"><h2>' + [Net.WebUtility]::HtmlEncode($ds.Name -replace '_',' ') + '</h2>')
    [void]$sb.AppendLine('<div class="desc">' + [Net.WebUtility]::HtmlEncode($ds.Description) + ' <b>Rows: ' + $ds.Rows + '</b>. HTML preview is limited to the first 200 rows.</div>')
    [void]$sb.AppendLine('<a class="download" href="CSVs/' + [Uri]::EscapeDataString($ds.FileName) + '">Open full CSV</a>')
    if ($ds.Rows -gt 0) {
        try {
            $fragment = ($ds.Preview | ConvertTo-Html -Fragment)
            [void]$sb.AppendLine($fragment)
        } catch { [void]$sb.AppendLine('<p>Preview could not be rendered. Use the CSV.</p>') }
    } else { [void]$sb.AppendLine('<p>No rows were returned for this artifact.</p>') }
    [void]$sb.AppendLine('</section>')
}

[void]$sb.AppendLine('<div class="footer">Collection ended ' + $collectionEnd.ToString('yyyy-MM-dd HH:mm:ss zzz') + '. This is live forensic triage, not a bit-for-bit acquisition. Full CSVs are in the CSVs folder; Triage_All_Findings.csv is a normalized consolidated export; SHA256SUMS.csv provides integrity hashes for generated output and core tool files.</div></div></body></html>')
[IO.File]::WriteAllText($reportPath, $sb.ToString(), (New-Object Text.UTF8Encoding($true)))

$completePath = Join-Path $script:OutputRoot 'COLLECTION_COMPLETE.txt'
@(
    'Windows USB Forensic Triage collection complete.',
    ('Computer: ' + $env:COMPUTERNAME),
    ('Start: ' + $CollectionStart.ToString('o')),
    ('End: ' + $collectionEnd.ToString('o')),
    ('Report: ' + $reportPath),
    ('Summary CSV: ' + $summaryPath),
    ('Consolidated CSV: ' + $allFindingsPath),
    'Review Collection_Notices.csv before drawing conclusions from absent evidence.'
) | Set-Content -LiteralPath $completePath -Encoding UTF8

try { Remove-Item -LiteralPath $script:TempRoot -Recurse -Force -ErrorAction SilentlyContinue } catch { }
Write-Log 'Collection and report generation complete. Generating SHA-256 integrity file.'
Write-UIStatus 'Running' 'Integrity hashing' 97 'Generating SHA-256 hashes for the report, CSV evidence, and collector files.' $reportPath $script:OutputRoot

$hashTargets = @()
$hashTargets += @(Get-ChildItem -LiteralPath $script:OutputRoot -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -ne 'SHA256SUMS.csv' })
foreach ($toolFile in @('Forensic_Triage.ps1','START_HERE.hta','README.md')) {
    $p = Join-Path $PSScriptRoot $toolFile
    if (Test-Path -LiteralPath $p) { $hashTargets += Get-Item -LiteralPath $p }
}
$hashRows = @()
foreach ($f in $hashTargets | Sort-Object FullName -Unique) {
    try {
        $h = Get-FileHash -LiteralPath $f.FullName -Algorithm SHA256 -ErrorAction Stop
        $rel = $f.FullName
        if ($f.FullName.StartsWith($PSScriptRoot, [StringComparison]::OrdinalIgnoreCase)) { $rel = $f.FullName.Substring($PSScriptRoot.Length).TrimStart('\') }
        $hashRows += [pscustomobject]@{ RelativePath=$rel; SizeBytes=$f.Length; SHA256=$h.Hash }
    } catch { }
}
$hashRows | Export-Csv -LiteralPath (Join-Path $script:OutputRoot 'SHA256SUMS.csv') -NoTypeInformation -Encoding UTF8 -Force

Write-Host ''
Write-Host 'TRIAGE COMPLETE' -ForegroundColor Green
Write-Host ("Output: {0}" -f $script:OutputRoot)
Write-Host ("HTML report: {0}" -f $reportPath)
Write-Host ("Summary CSV: {0}" -f $summaryPath)
Write-Host ("Integrity hashes: {0}" -f (Join-Path $script:OutputRoot 'SHA256SUMS.csv'))
Write-Host ''
Write-UIStatus 'Complete' 'Complete' 100 'Forensic triage completed successfully. The HTML report and CSV evidence tables are ready.' $reportPath $script:OutputRoot
if ([string]::IsNullOrWhiteSpace($StatusFile)) {
    try { Start-Process -FilePath $reportPath } catch { Write-Host 'Could not automatically open the HTML report. Open Triage_Report.html manually.' -ForegroundColor Yellow }
}
exit 0
