# Windows USB Forensic Triage 1.1.0 — HTML Application Edition

This edition is designed so the examiner works entirely from `START_HERE.hta`.

## Examiner workflow

1. Copy this folder to a writable USB device.
2. Insert the USB into the authorized Windows computer.
3. Double-click `START_HERE.hta`.
4. Choose the collection options and check the authorization confirmation box.
5. Click **Run Forensic Triage**.
6. Approve the normal Windows UAC prompt.
7. Watch progress in the HTML application. When collection completes, the generated HTML report is loaded in the same interface. CSV evidence tables remain on the USB.

The examiner does **not** need to open PowerShell, a command prompt, or type commands. `Forensic_Triage.ps1` is the background collection engine invoked by the HTML Application.

## Why `.hta` instead of ordinary `.html`?

Modern browsers deliberately sandbox ordinary local HTML pages and do not allow them to execute arbitrary local PowerShell or read protected forensic artifacts. Windows HTML Application (`.hta`) files use HTML/CSS/JavaScript for the interface while permitting a locally launched, authorized Windows utility to invoke the collector. The UAC prompt is still required for elevated collection.

Some organizations block `mshta.exe` with WDAC, AppLocker, EDR, or application-control policy. This package does not bypass those controls. If HTA execution is prohibited by policy, the organization must explicitly permit the signed/approved triage utility or use another organization-approved launcher.

## Output

Each run creates:

`TRIAGE_OUTPUT\<COMPUTERNAME>_<TIMESTAMP>\`

with:

- `Triage_Report.html`
- `Triage_Summary.csv`
- `Triage_All_Findings.csv`
- `CSVs\` containing artifact-specific CSV evidence tables
- `Collection_Log.txt`
- `Collection_Notices.csv`
- `SHA256SUMS.csv`
- `COLLECTION_COMPLETE.txt`

The interface can load the latest generated report and open the evidence folder directly.

## Collection scope

The collector includes host/OS metadata, local accounts and profiles, login history, process creation where audited, USB history, browser and download history, installed software, Prefetch, BAM/DAM, running processes, services, network state, recent-file evidence, Downloads metadata, Recycle Bin history, persistence locations, scheduled tasks, RDP history, Defender detections, selected event-log summaries, audit-policy context, and a forensic artifact inventory.

## Forensic limitation

This is live-response triage, not a bit-for-bit acquisition. Running it necessarily creates normal Windows process, event, cache, and file-system traces. Empty data sets must be interpreted alongside `Collection_Notices.csv`, because auditing, retention, permissions, locked databases, disabled components, encrypted profiles, or endpoint policy can reduce coverage.
